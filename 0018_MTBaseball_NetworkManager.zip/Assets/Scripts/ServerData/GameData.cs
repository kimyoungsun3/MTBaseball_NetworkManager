using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameData {

	#region etc
	public static string 	pathUrl = "";
	public static string 	recurl = "";
	public static int 		lastBuyCashCode = 0;
	#endregion


}
