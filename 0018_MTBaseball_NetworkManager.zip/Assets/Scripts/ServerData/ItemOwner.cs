﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemOwner {
	public int listIdx;
	public int invenkKind;
	public int itemcode;
	public int cnt;
	public int randSerial;
}
